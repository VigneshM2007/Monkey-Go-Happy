var PLAY = 1;
var END = 0;
var gameState = PLAY;
var monkey , monkey_running
var obstacleImage,obstaclesGroup

var score
var survivalTime=0;

var bananaGroup, bananaImage;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacle1 = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(400, 400);
  monkey=createSprite(80,315,20,20)
  monkey.addAnimation("moving", monkey_running);
  monkey.scale = 0.1
  
  ground = createSprite(400,360,900,10);
  ground.velocityX=-4;
  ground.x=ground.width/2
  
  score = 0;
  
  
  //monkey.setCollider("circle",10,10,40);
  bananaGroup = createGroup();
  obstaclesGroup = createGroup();
}


function draw() {
  background(255);
  monkey.collide(ground);
  drawSprites()
   stroke("white");
   textSize(20);
  text("Score: "+ score, 200,100);
  text.scale = 0.2
  fill("black")
   
  if(gameState === PLAY){
    
    //move the ground
    ground.velocityX = -(4+3*score/100);
    //scoring
    score = score + Math.round(frameCount/60);
    if (score > 0 && score % 100=== 0){
      
    }
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
    
    //jump when the space key is pressed
    if(keyDown("space")&& monkey.y >= 160) {
        monkey.velocityY = -10;
      
    }
    
    //add gravity
    monkey.velocityY = monkey.velocityY + 1
    spawnBanana();
    spawnObstacle();
    
    //monkey.collide(ground)
    
    
    if(bananaGroup.isTouching(monkey)){
      bananaGroup.destroyEach();
      score = score + 150;
    }
    
    
  if(obstaclesGroup.isTouching(monkey)){
   monkey.visible = false
    gameState = END;
    ground.visible = false
    text.visible = false
  }
  
  }
       else if (gameState === END) {
         bananaGroup.destroyEach();
         text("Game Over", 180,200);
         obstaclesGroup.destroyEach();
         
       }
  
  
    
  
}



function spawnBanana() {
  //write code here to spawn the clouds
  if (frameCount % 240 === 0) {
     banana = createSprite(401,200,40,10);
    //cloud.y = Math.round(random(0,60));
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    banana.velocityX = -5;
    
     //assign lifetime to the variable
    banana.lifetime = 250;
    
    //adjust the depth
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    //adding cloud to the group
   bananaGroup.add(banana);
    }
}

function spawnObstacle() {
  //write code here to spawn the clouds
  if (frameCount % 120 === 0) {
     Obstacle = createSprite(401,325,40,10);
    //cloud.y = Math.round(random(0,60));
    Obstacle.addImage(obstacle1);
    Obstacle.scale = 0.15;
    Obstacle.velocityX = -5;
    
     //assign lifetime to the variable
    Obstacle.lifetime = 250;
    
    //adjust the depth
    Obstacle.depth = monkey.depth;
    Obstacle.depth = monkey.depth + 1;
    
    //adding cloud to the group
   obstaclesGroup.add(Obstacle);
    }
}